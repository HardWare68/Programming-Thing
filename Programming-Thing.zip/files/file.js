//this function prints stuff to the screen
function whatAmIDoing(){
  console.log("lmaoooo");
}

//test stuff again
function testStuffAgain(){
  console.log("Hello #alex-post-archives!");
}

//export this bad boy
module.exports = { whatAmIDoing, testStuffAgain };